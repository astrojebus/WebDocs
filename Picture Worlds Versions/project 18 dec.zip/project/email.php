<?php 
if(isset($_POST['submit']))
{
    $to = "abc@gmail.com"; // this is your Email address
    $name = $_POST['name'];
    $message = $_POST['message']; 
    $visitor_email = $_POST['email']; 

$email_from ="abcde@yahoo.com";
$email_subject = "New Email ";
$email_body = "User Name: $name.\n".
                "User Email: $email_from.\n".
                 "User Message: $message.\n";

$to = "abc@gmail.com";
$headers = "From: $email_from \r\n";
$headers =  "Reply to: $visitor_email \r\n";

mail($to, $email_subject, $email_body, $headers);
echo "<script> alert ('Email send successfully')  </script>";

}
?>